const headers = { 'content-Type': 'application/json' }
export default headers
